import info.gridworld.actor.Actor;
import info.gridworld.actor.Flower;
import info.gridworld.actor.Rock;
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;
import Java.awt.Color;

/**
 * A <code>Jumper</code> can jump over rocks and flowers that in front of it.<br />
 * It is an Actor.
 */
public class Jumper extends Actor
{
    /**
     * Constructs a red Jumper
     */
    public Jumper()
    {
        setColor(Color.RED);
    }

    /**
     * Constructs a Jumper of a given color.
     * @param JumpColor the color for this Jumper
     */
    public Jumper(Color JumpColor)
    {
        setColor(JumpColor);
    }

    /**
     * Jump if it can Jump, turns otherwise.
     */
    public void act()
    {
        if (canJump())
            jump();
        else
            turn();
    }

    /**
     * Turns the Jumper 45 degrees to the right without changing its location.
     */
    public void turn()
    {
        setDirection(getDirection() + Location.HALF_RIGHT);
    }

    /**
     * Moves the Jumper forward two location.
     */
    public void jump()
    {
        Grid<Actor> gr = getGrid();
        if (gr == null)
            return;
        Location loc = getLocation();
        Location next = loc.getAdjacentLocation(getDirection());
        Location next2 = next.getAdjacentLocation(getDirection());
        if (gr.isValid(next2))
            moveTo(next2);
        else
            removeSelfFromGrid();
    }

    /**
     * Tests whether this jumper can jump forward two lication 
     * into a location that is empty or
     * contains a flower.
     * @return true if this jumper can move.
     */
    public boolean canJump()
    {
        Grid<Actor> gr = getGrid();
        if (gr == null)
            return false;
        Location loc = getLocation();
        Location next = loc.getAdjacentLocation(getDirection());
        /*if (!gr.isValid(next))
            return false;*/
        Actor neighbor = gr.get(next);
        //return (neighbor == null) || (neighbor instanceof Flower);
        Location next2 = next.getAdjacentLocation(getDirection());
        if (!gr.isValid(next2))
            return false;
        neighbor = gr.get(next2);
        return (neighbor == null) || (neighbor instanceof Flower);
        // ok to move into empty location or onto flower
        // not ok to move onto any other actor
    }
}
