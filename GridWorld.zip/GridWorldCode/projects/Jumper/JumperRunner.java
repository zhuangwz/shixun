import info.gridworld.actor.ActorWorld;
import info.gridworld.grid.Location;
import info.gridworld.actor.Bug;
import info.gridworld.actor.Rock;
import info.gridworld.actor.Flower;


/**
 * This class runs a world that contains bugs,rocks,jumper,flower. <br />
 * This class is not tested on the AP CS A and AB exams.
 */
public class JumperRunner
{
    public static void main(String[] args)
    {
        ActorWorld world = new ActorWorld();
        Jumper alice = new Jumper();
        world.add(alice);
        world.add(new Bug());
        world.add(new Rock());
        world.add(new Flower());
        world.show();
    }
}