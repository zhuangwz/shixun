import info.gridworld.grid.Grid;
import info.gridworld.grid.AbstractGrid;
import info.gridworld.grid.Location;

import java.util.ArrayList;

import java.util.*;

/**
 * An <code>UnboundedGrid</code> is a rectangular grid with an unbounded number of rows and
 * columns. <br />
 * The implementation of this class is testable on the AP CS AB exam.
 */
public class UnboundedGrid2<E> extends AbstractGrid<E>
{
    private Object[][] occupantMap;
    private int dimension;

    /**
     * Constructs an empty unbounded grid.
     */
    public UnboundedGrid2()
    {
        dimension = 16;
        occupantMap = new Object[dimension][dimension];
    }

    public int getNumRows()
    {
        return -1;
    }

    public int getNumCols()
    {
        return -1;
    }

    public boolean isValid(Location loc)
    {
        return loc.getRow() >=0 && loc.getCol() >= 0;
    }

    public ArrayList<Location> getOccupiedLocations()
    {
        ArrayList<Location> a = new ArrayList<Location>();
        for(int i=0;i<dimension;i++){
            for(int j=0;j<dimension;j++){
                Location loc = new Location(i,j);
                if(get(loc) != null)
                    a.add(loc);
            }
        }
        return a;
    }

    public E get(Location loc)
    {
        //row and column must equal or bigger than zero
        if (!isValid(loc))
            throw new IllegalArgumentException("Location " + loc
                    + " is not valid");
        if (loc == null)
            throw new NullPointerException("loc == null");
        if(loc.getRow() >= dimension || loc.getCol() >= dimension)
            return null;
        return (E) occupantMap[loc.getRow()][loc.getCol()];  //unavoidable warning
    }

    public E put(Location loc, E obj)
    {
        if (loc == null)
            throw new NullPointerException("loc == null");
        if (obj == null)
            throw new NullPointerException("obj == null");

        while(loc.getRow() >= dimension || loc.getCol() >= dimension)
            larger();
        E old = get(loc);
        occupantMap[loc.getRow()][loc.getCol()] = obj;
        return old;
    }

    private void larger(){
        //new dimension
        int new_dimension = dimension * 2;
        //new Array
        Object[][] new_array = new Object[new_dimension][new_dimension];

        //copy from the old array to new array
        for(int i=0;i<dimension;i++){
            for(int j=0;j<dimension;j++)
                new_array[i][j] = occupantMap[i][j];
        }
        occupantMap = new_array;
        dimension = new_dimension;
    }

    public E remove(Location loc)
    {
        if (!isValid(loc))
            throw new IllegalArgumentException("Location " + loc
                    + " is not valid");
        if (loc == null)
            throw new NullPointerException("loc == null");
        //If the Location is out of the valid location, return null;
        if(loc.getCol() >= dimension || loc.getRow() >= dimension)
            return null;

        // Remove the object from the grid.
        E old = get(loc);
        occupantMap[loc.getRow()][loc.getCol()] = null;
        return old;
    }


}
