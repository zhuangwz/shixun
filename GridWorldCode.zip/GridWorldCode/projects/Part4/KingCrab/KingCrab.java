import info.gridworld.actor.Actor;
import info.gridworld.actor.Critter;
import info.gridworld.grid.Location;
import info.gridworld.grid.Grid;
import java.util.ArrayList;
import java.awt.Color;

/**
 * A <code>KingCrab</code> causes each actor that it processes to move
 * one location further away from it.
 */
public class KingCrab extends CrabCritter{
	/**
     * Constructs a KingCrab.
     */
	public KingCrab(){
		super();
	}

    /**
     * The actor will be move one position away from the kingcrab.
     * If move success, return true. Otherwise, return false;
     */
    private boolean moveAway(Actor a){
        Location loc = getLocation();
        ArrayList<Location> locs = getGrid().getEmptyAdjacentLocations(a.getLocation());
        int dir = getDirection();

        for(Location temp : locs){
            if(dir == 0){
                if(!(temp.getRow() == loc.getRow()-1 && 
                    Math.abs(temp.getCol() - loc.getCol()) <=1 ) ){
                    a.moveTo(temp);
                    return true;
                }
            }
            else if(dir == 180){
                if(!(temp.getRow() == loc.getRow()+1 && 
                    Math.abs(temp.getCol() - loc.getCol()) <=1 ) ){
                    a.moveTo(temp);
                    return true;
                }
            }
            else if(dir == 90){
                if(!(temp.getCol() == loc.getCol()+1 && 
                    Math.abs(temp.getRow() - loc.getRow()) <=1 ) ){
                    a.moveTo(temp);
                    return true;
                }
            }
            else if(dir == 270){
                if(!(temp.getCol() == loc.getCol()-1 && 
                    Math.abs(temp.getRow() - loc.getRow()) <=1 ) ){
                    a.moveTo(temp);
                    return true;
                }
            }
        }
        return false;
    }

	/**Processes the elements of <code>actors</code>. Each one of it will 
     * move one position away from the KingCrab. If it can't be move, 
     * it will be remove from the grid <br />
     * Postcondition: (1) The state of all actors in the grid other than this
     * critter and the elements of <code>actors</code> is unchanged. (2) The
     * location of this critter is unchanged.
     * @param actors the actors to be processed
     */
    public void processActors(ArrayList<Actor> actors)
    {
        for (Actor a : actors)
        {
            if (!moveAway(a))
                a.removeSelfFromGrid();
        }
    }
}