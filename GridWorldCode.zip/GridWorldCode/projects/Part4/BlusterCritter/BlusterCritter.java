import info.gridworld.actor.Actor;
import info.gridworld.actor.Critter;
import info.gridworld.grid.Location;
import info.gridworld.grid.Grid;
import java.util.ArrayList;
import java.awt.Color;

/**
 * A <code>BluterCritter</code> will lighten if the number of the actors 
 * that occupy neighboring grid locations within two steps 
 * is bigger than the c Critters. Otherwise, darken.
 */
public class BlusterCritter extends Critter{
	private int critter_num;

	/**
     * Constructs a ChameleonCritter.
     */
	public BlusterCritter(int cn){
		super();
		critter_num = cn;
        setColor(new Color(100,100,100));
	}

	/**
     * Gets the actors for processing. Implemented to return the actors that
     * occupy neighboring grid locations within two steps. 
     * Override this method in subclasses to
     * look elsewhere for actors to process.<br />
     * Postcondition: The state of all actors is unchanged.
     * @return a list of actors that this critter wishes to process.
     */
    public ArrayList<Actor> getActors()
    {
        ArrayList<Actor> actors = new ArrayList<>();
        Location loc = this.getLocation();
        for(int i = loc.getRow() -2; i <= loc.getRow()+2; i++){
        	for(int j=loc.getCol()-2; j<= loc.getCol()+2; j++){
        		if(i == 0 && j == 0)
        			continue;
        		Location temp = new Location(i,j);
        		if(getGrid().isValid(temp)){
        			Actor a = getGrid().get(temp);
        			if(a != null){
        				actors.add(a);
        			}
        		}
        	}
        }
        return actors;
    }

    /**
     * Processes the elements of <code>actors</code>. Implemented to count 
     * all the Critters within two steps to the BlusterCritter.
     * If there are fewer Critters than c Critters, it lightens.
     * otherwise, it darkens. <br />
     * Postcondition: (1) The state of all actors in the grid other than this
     * critter and the elements of <code>actors</code> is unchanged. (2) The
     * location of this critter is unchanged.
     * @param actors the actors to be processed
     */
    public void processActors(ArrayList<Actor> actors)
    {
    	int count = 0;
        for (Actor a : actors)
        {
            if (a instanceof Critter)
                count++;
        }
        if(count > critter_num)
        	darken();
        else
        	lighten();
    }

    /**
     * Lighten the BlusterCritter 
     */
    private void lighten(){
        Color c = getColor();
        int red = (int)c.getRed();
        int green = (int)c.getGreen();
        int blue = (int)c.getBlue();
        red = red < 235 ? red +20 : red;
        green = green < 235 ? green +20 : green;
        blue = blue < 235 ? blue +20 : blue;

        setColor(new Color(red, green, blue));
    }

    /**
     * Darken the BlusterCritter
     */
    private void darken(){
    	Color c = getColor();
        int red = (int)c.getRed();
        int green = (int)c.getGreen();
        int blue = (int)c.getBlue();
        red = (red > 20) ? red -20 : red;
        green = (green > 20) ? green -20 : green;
        blue = (blue > 20) ? blue -20 : blue;

        setColor(new Color(red, green, blue));
    }
}