import info.gridworld.actor.Actor;
import info.gridworld.actor.Critter;
import info.gridworld.grid.Location;
import info.gridworld.grid.Grid;
import java.util.ArrayList;
import java.awt.Color;

/**
 * A <code>QuickCrab</code> can move two spaces if that location and 
 * intervening location are both empty.
 */
public class QuickCrab extends CrabCritter{
	/**
     * Constructs a QuickCrab.
     */
	public QuickCrab(){
		super();
	}

	/**
     * @return list of empty locations immediately to the right and to the left
     */
    public ArrayList<Location> getMoveLocations()
    {
        ArrayList<Location> locs = new ArrayList<Location>();
        Location loc = getLocation();
        int dir = getDirection();
        Grid g = getGrid();
        int row = loc.getRow();
        int col = loc.getCol();

        if(dir%180 == 0){
            if(g.isValid(new Location(row,col-1))&&g.get(new Location(row,col-1))==null
                &&g.isValid(new Location(row,col+1))&&g.get(new Location(row,col+1))==null
                &&g.isValid(new Location(row,col-2))&&g.get(new Location(row,col-2))==null
                &&g.isValid(new Location(row,col+2))&&g.get(new Location(row,col+2))==null){
                locs.add(new Location(row,col-2));
                locs.add(new Location(row,col+2));
            }
        }
        else if(dir%90 == 0){
            if(g.isValid(new Location(row-1,col))&&g.get(new Location(row-1,col))==null
                &&g.isValid(new Location(row+1,col))&&g.get(new Location(row+1,col))==null
                &&g.isValid(new Location(row-2,col))&&g.get(new Location(row-2,col))==null
                &&g.isValid(new Location(row+2,col))&&g.get(new Location(row+2,col))==null){
                locs.add(new Location(row,col-2));
                locs.add(new Location(row,col+2));
            }
        }

    	if(locs.size() == 0)
    		return super.getMoveLocations();

        return locs;
    }
}