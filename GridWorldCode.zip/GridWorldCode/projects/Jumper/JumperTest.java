/* 
 * AP(r) Computer Science GridWorld Case Study:
 * Copyright(c) 2005-2006 Cay S. Horstmann (http://horstmann.com)
 *
 * This code is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * @author Cay Horstmann
 * @author Chris Nevison
 * @author Barbara Cloud Wells
 */

import info.gridworld.actor.ActorWorld;
import info.gridworld.grid.Location;
import info.gridworld.actor.Rock;
import info.gridworld.actor.Flower;

import static org.junit.Assert.*;
import org.junit.Test;

import java.awt.Color;


//javac -classpath .:../../gridworld.jar:junit-4.9.jar JumperTest.java 
//java -classpath .:../../gridworld.jar:junit-4.9.jar -ea org.junit.runner.JUnitCore  JumperTest


/**
 * This class runs a world that contains box bugs. <br />
 * This class is not tested on the AP CS A and AB exams.
 */
public class JumperTest
{
    private ActorWorld world = new ActorWorld();
    Jumper jum = new Jumper();


    @Test
    public void RockTest()
    {
        world.add(new Location(5, 5), jum);
        world.add(new Location(4, 5), new Rock());
        //jum.act();
        assertEquals(true, jum.canJump());
        jum.removeSelfFromGrid();
    }

    @Test
    public void FlowerTest()
    {
        world.add(new Location(5, 5), jum);
        world.add(new Location(4, 5), new Flower());
        assertEquals(true, jum.canJump());
        jum.removeSelfFromGrid();
    }

    @Test
    public void EdgeTest()
    {
        world.add(new Location(1, 5), jum);
        assertEquals(false, jum.canJump());
        jum.removeSelfFromGrid();
    }

    @Test
    public void MeetTest()
    {
        Jumper test_a = new Jumper(Color.ORANGE);
        Jumper test_b =  new Jumper();
        world.add(new Location(8, 5), test_a);
        world.add(new Location(2, 3), test_b);
        for(int i=0; i<3; i++)
        {
            test_a.act();
            test_b.act();
        }
        assertEquals(true,  test_a.canJump());
        assertEquals(true,  test_b.canJump());
        test_a.act();
        assertEquals(false,  test_b.canJump());
        test_a.removeSelfFromGrid();
        test_b.removeSelfFromGrid();
    }

}