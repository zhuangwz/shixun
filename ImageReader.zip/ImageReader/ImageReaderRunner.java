import ImageReader.IImageIO;
import ImageReader.IImageProcessor;
import ImageReader.Runner;

public class ImageReaderRunner {
    public static void main(String... args){
        IImageIO imageioer = new ImplementImageIO();
        IImageProcessor processor = new ImplementImageProcessor();
        Runner.run(imageioer,processor);
    }
}
