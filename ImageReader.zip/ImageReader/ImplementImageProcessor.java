import java.awt.*;
import java.awt.image.FilteredImageSource;
import java.awt.image.RGBImageFilter;

public class ImplementImageProcessor implements IImageProcessor {
    //红色滤波器
    class redFilter extends RGBImageFilter{
        public redFilter(){

        }

        @Override
        public int filterRGB(int x, int y, int rgb) {
            return rgb & 0xffff0000;
        }
    }
    //绿色滤波器
    class greenFilter extends RGBImageFilter{
        public greenFilter(){

        }

        @Override
        public int filterRGB(int x, int y, int rgb) {
            return rgb & 0xff00ff00;
        }
    }
    //蓝色滤波器
    class blueFilter extends RGBImageFilter{
        public blueFilter(){}

        @Override
        public int filterRGB(int x, int y, int rgb) {
            return rgb & 0xff0000ff;
        }
    }
    //灰色滤波器
    class grayFilter extends RGBImageFilter{
        public grayFilter(){

        }

        @Override
        public int filterRGB(int x, int y, int rgb) {
            int gray = (int)((((rgb & 0x00ff0000) >> 16) * 0.299) + (((rgb & 0x0000ff00) >> 8) * 0.587) + ((rgb & 0x000000ff) * 0.114));
            return (rgb & 0xff000000) + (rgb & (gray << 16) ) + (rgb & (gray << 8)) + gray;
        }
    }

    @Override
    public Image showChanelR(Image image) {
        redFilter red = new redFilter();
        return Toolkit.getDefaultToolkit().createImage(new FilteredImageSource(image.getSource(),red));
    }

    @Override
    public Image showChanelG(Image image) {
        greenFilter green = new greenFilter();
        return Toolkit.getDefaultToolkit().createImage(new FilteredImageSource(image.getSource(),green));
    }

    @Override
    public Image showChanelB(Image image) {
        blueFilter blue = new blueFilter();
        return Toolkit.getDefaultToolkit().createImage(new FilteredImageSource(image.getSource(),blue));
    }

    @Override
    public Image showGray(Image image) {
        grayFilter gray = new grayFilter();
        return Toolkit.getDefaultToolkit().createImage(new FilteredImageSource(image.getSource(),gray));
    }
}
