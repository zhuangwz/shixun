/* 
 * AP(r) Computer Science GridWorld Case Study:
 * Copyright(c) 2005-2006 Cay S. Horstmann (http://horstmann.com)
 *
 * This code is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * @author Cay Horstmann
 * @author Chris Nevison
 * @author Barbara Cloud Wells
 */

import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

import java.io.FileInputStream;
import java.awt.*;
import java.lang.String;
import javax.imageio.*;
import java.util.Arrays;
import java.util.Collection;

//javac -classpath .:junit-4.9.jar ImageReaderTest.java 
//java -classpath .:junit-4.9.jar -ea org.junit.runner.JUnitCore  ImageReaderTest


/**
 * This class is not tested on the AP CS A and AB exams.
 */
@RunWith(Parameterized.class)
public class ImageReaderTest
{
    private FileInputStream fis1;
    private Image image1;
    private FileInputStream fis2;
    private Image image2;

    @Parameters
    public static Collection<Object[]> data(){
        return Arrays.asList(new Object[][]{
            {"/home/user/Desktop/bmptest/test/1_blue_goal.bmp","/home/user/Desktop/bmptest/goal/1_blue_goal.bmp"},
            {"/home/user/Desktop/bmptest/test/1_red_goal.bmp","/home/user/Desktop/bmptest/goal/1_red_goal.bmp"},
            {"/home/user/Desktop/bmptest/test/1_green_goal.bmp","/home/user/Desktop/bmptest/goal/1_green_goal.bmp"},
            {"/home/user/Desktop/bmptest/test/1_gray_goal.bmp","/home/user/Desktop/bmptest/goal/1_gray_goal.bmp"},
            {"/home/user/Desktop/bmptest/test/2_blue_goal.bmp","/home/user/Desktop/bmptest/goal/2_blue_goal.bmp"},
            {"/home/user/Desktop/bmptest/test/2_red_goal.bmp","/home/user/Desktop/bmptest/goal/2_red_goal.bmp"},
            {"/home/user/Desktop/bmptest/test/2_green_goal.bmp","/home/user/Desktop/bmptest/goal/2_green_goal.bmp"},
            {"/home/user/Desktop/bmptest/test/2_gray_goal.bmp","/home/user/Desktop/bmptest/goal/2_gray_goal.bmp"}
        });
    }

    public ImageReaderTest(String s1,String s2){
        fis1 = new FileInputStream(s1);
        fis2 = new FileInputStream(s2);
        image1 = ImageIO.read(fis1);
        image2 = ImageIO.read(fis2);
    }

    //比较位图宽度
    @Test
    public void WidthTest(){
        assertEquals(image1.getWidth(null),image2.getWidth(null));
    }

    //比较位图高度
    @Test
    public void HeightTest(){
        assertEquals(image1.getHeight(null),image2.getHeight(null));
    }

    //比较位图像素值
    @Test
    public void PixValueTest(){
        int size = pimage1.getheight(null) * pimage1.getwidth(null);
        byte bt1[] = new byte[size];
        byte bt2[] = new byte[size];
            
        //跳过不属于位图信息的部分
        fis1.skip(54);
        fis2.skip(54);
            
        pfile0.read(bt1);
        pfile1.read(bt2);
        assertequals(bt1, bt2);
    }
}