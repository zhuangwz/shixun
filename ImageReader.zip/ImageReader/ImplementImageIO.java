import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.image.MemoryImageSource;
import java.awt.image.RenderedImage;
import java.io.File;
import java.io.FileInputStream;

public class ImplementImageIO implements IImageIO {
    public class BitmapHeader{
        public int type; //标识符
        public int size; //位图文件大小
        public int reserve; //保留部分，拓展使用
        public int address; //数据起始位置

        public BitmapHeader(FileInputStream fis){
            reserve = 0;
            type = 16973;
            address = 0;
            try{
                byte[] bt = new byte[14];
                if(fis.read(bt) != -1){
                    size = (((int)bt[5] & 0xff) << 24) | (((int)bt[4] & 0xff) << 16)
                            | (((int)bt[3] & 0xff) << 8) | ((int)bt[2] & 0xff) ;
                }
            }catch(Exception e){
                e.printStackTrace();
            }
        }
    }

    public class BitmapInfoHeader{
        public int size;    //影像的区块大小
        public int width;   //位图宽度
        public int height;  //位图高度
        public int num;     //所用彩色位面的个数
        public int count;   //每个像素的位数。是图像的颜色深度
        public int compress;//所用的压缩算法
        public int image_size;    //原始位图数据的大小
        public int hori;    //水平方向分辨率
        public int verti;   //竖直方向分辨率
        public int color_used;//所用颜色数目
        public int color_important;//重要颜色的数目

        public int[] info;      //保存图像信息

        public BitmapInfoHeader(FileInputStream fis){
            try{
                byte[] bt = new byte[40];
                if(fis.read(bt) != -1){
                    size = (((int)bt[3] & 0xff) << 24) | (((int)bt[2] & 0xff) << 16)
                            | (((int)bt[1] & 0xff) << 8) | (int)bt[0] & 0xff ;
                    width = (((int)bt[7] & 0xff) << 24) | (((int)bt[6] & 0xff) << 16)
                            | (((int)bt[5] & 0xff) << 8) | (int)bt[4] & 0xff ;
                    height = (((int)bt[11] & 0xff) << 24) | (((int)bt[10] & 0xff) << 16)
                            | (((int)bt[9] & 0xff) << 8) | (int)bt[8] & 0xff ;
                    num = (((int)bt[13] & 0xff) << 8) | (int)bt[12] & 0xff ;
                    count = (((int)bt[15] & 0xff) << 8) | (int)bt[14] & 0xff ;
                    compress = (((int)bt[19]) << 24) | (((int)bt[18]) << 16)
                            | (((int)bt[17]) << 8) | (int)bt[16] ;
                    image_size = (((int)bt[23] & 0xff) << 24) | (((int)bt[22] & 0xff) << 16)
                            | (((int)bt[21] & 0xff) << 8) | (int)bt[20] & 0xff;
                    hori = (((int)bt[27] & 0xff) << 24) | (((int)bt[26] & 0xff) << 16)
                            | (((int)bt[25] & 0xff) << 8) | (int)bt[24] & 0xff;
                    verti = (((int)bt[31] & 0xff) << 24) | (((int)bt[30] & 0xff) << 16)
                            | (((int)bt[29] & 0xff) << 8) | (int)bt[28] & 0xff;
                    color_used = (((int)bt[35] & 0xff) << 24) | (((int)bt[34] & 0xff) << 16)
                            | (((int)bt[33] & 0xff) << 8) | (int)bt[32] & 0xff;
                    color_important = (((int)bt[39] & 0xff) << 24) | (((int)bt[38] & 0xff) << 16)
                            | (((int)bt[37] & 0xff) << 8) | (int)bt[36] & 0xff;
                }
                if(count == 24){
                    int temp = image_size/height - width * 3;
                    if(temp == 4)
                        temp = 0;
                    info = new int[height * width];
                    byte[] rgb = new byte[image_size];
                    int index = 0;
                    if(fis.read(rgb) != -1) {
                        for (int j = 0; j < height; j++) {
                            for (int i = 0; i < width; i++) {
                                info[width * (height - j - 1) + i] =
                                        (255 & 0xff) << 24 | (((int)rgb[index + 2] & 0xff) << 16)
                                         | (((int)rgb[index + 1] & 0xff) << 8) | (int) rgb[index] & 0xff;
                                index += 3;
                            }
                            index += temp;
                        }
                    }
                }

            }catch (Exception e){
                e.printStackTrace();
            }
        }

        public Image getImage(){
            Image image = null;
            image = Toolkit.getDefaultToolkit().createImage(
                    new MemoryImageSource(width,height,info,0,width)
            );
            return image;
        }
    }

    @Override
    public Image myRead(String filePath) {
        Image image = null;
        try{
            //读取文件
            FileInputStream fis = new FileInputStream(filePath);
            //保存位图头
            BitmapHeader bmh = new BitmapHeader(fis);
            //保存位图信息
            BitmapInfoHeader bmi = new BitmapInfoHeader(fis);

            image = bmi.getImage();
            fis.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return image;
    }

    @Override
    public Image myWrite(Image image, String filePath) {
        try{
            //文件输出
            File file = new File(filePath + ".bmp");
            //形成图像数据
            BufferedImage bimg = new BufferedImage(image.getWidth(null),image.getHeight(null),BufferedImage.TYPE_INT_RGB);
            //写入文件
            ImageIO.write(bimg,"bmp",file);
        }catch (Exception e){
            e.printStackTrace();
        }
        return image;
    }
}
