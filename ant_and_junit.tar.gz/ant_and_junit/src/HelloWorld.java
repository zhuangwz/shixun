import java.util.*;

public class HelloWorld{
	String str;
	public void hello(){
		str= "Hello World!";
	}
	public String getStr(){
		return str;
	}
}