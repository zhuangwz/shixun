import static org.junit.Assert.*;
import org.junit.Test;

public class TestHelloWorld{
	public HelloWorld helloworld = new HelloWorld();
	public void testHello(){
		helloworld.hello();
		assertEquals("Hello World!",helloworld.getStr());
	}
	public void setUp() throws Exception{}
	public void tearDown() throws Exception{}
}