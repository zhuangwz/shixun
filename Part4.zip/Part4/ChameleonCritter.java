package info.gridworld.actor;

import java.awt.Color;
import info.gridworld.grid.Location;
import java.util.ArrayList;
import info.gridworld.actor.Critter;
import info.gridworld.grid.Grid;

/**
 * A <code>ChameleonCritter</code> is a critter that don't eat anything.
 * The API of this class is testable on the AP CS A and AB exams.
 */

public class ChameleonCritter extends Critter
{
    private static final double DARKENING_FACTOR = 0.05;

    // lose 5% of color value in each step

    /**
     * Constructs a ChameleonCritter.
     */
    public ChameleonCritter()
    {
        super();
    }

    /**
     * Causes the color of this Critter to darken.
     * Or copy the neighbors' color.
     */
    public void processActors(ArrayList<Actor> actors){
        int size = actors.size();
        if(size == 0)
            darken();
        else{
            int r = (int) (Math.random() * size);
            setColor(actors.get(select).getColor());
        }
    }

    /**
     * Repert from the Flower class
     */
    public void darken(){
        Color c = getColor();
        int red = (int) (c.getRed() * (1 - DARKENING_FACTOR));
        int green = (int) (c.getGreen() * (1 - DARKENING_FACTOR));
        int blue = (int) (c.getBlue() * (1 - DARKENING_FACTOR));

        setColor(new Color(red, green, blue));
    }

    /**
     * Moves this critter to the given location <code>loc</code>, or removes
     * this critter from its grid if <code>loc</code> is <code>null</code>.
     * An actor may be added to the old location. If there is a different actor
     * at location <code>loc</code>, that actor is removed from the grid.<br />
     * Postcondition: (1) <code>getLocation() == loc</code>. (2) The state of
     * all actors other than those at the old and new locations is unchanged.
     * @param loc the location to move to
     */
    public void makeMove(Location loc){
        if (loc == null)
            removeSelfFromGrid();
        else
            moveTo(loc);
    }
}