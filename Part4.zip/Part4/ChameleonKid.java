import info.gridworld.actor.Actor;
import info.gridworld.actor.Critter;
import info.gridworld.grid.Location;
import info.gridworld.grid.Grid;
import Java.util.ArrayList;

public class ChameleonKid extends ChameleonCritter
{
	/**
     * Gets the actors for processing. Implemented to return the actors that
     * occupy in front, or behind of the ChameleonCritter.<br />
     * Postcondition: The state of all actors is unchanged.
     * @return a list of actors that this chameleonCritter wishes to process.
     */
    public ArrayList<Actor> getActors()
    {
        ArrayList<Actor> actors = new ArrayList<>();
        ArrayList<Actor> res = new ArrayList<>();
        actors = getGrid().getNeighbors(getLocation());
        for (Actor a : actors)
        {
            if(this.getDirection()%180 == 0 )
            {
            	if(a.getLocation().getCol() == this.getLocation().getCol())
                	res.add(a);
            }
            else if(this.getDirection()%180 == 90 && 
                a.getLocation().getRow() == this.getLocation().getRow() ){
                res.add(a);
            }
        }
        return res;
    }
}