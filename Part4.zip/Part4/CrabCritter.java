package info.gridworld.actor;

import java.awt.Color;
import info.gridworld.grid.Location;
import java.util.ArrayList;
import info.gridworld.actor.Critter;
import info.gridworld.grid.Grid;

/**
 * A <code>CrabCritter</code> is a critter that only move to left or right.
 * The API of this class is testable on the AP CS A and AB exams.
 */

public class CrabCritter extends Critter
{
    /**
     * Constructs a crabcritter.
     */
    public CrabCritter()
    {
        super();
    }


    /**
     * Gets the actors for processing. Implemented to return the actors that
     * occupy in front, left-front or right-front of the CrabCritter.<br />
     * Postcondition: The state of all actors is unchanged.
     * @return a list of actors that this crabcritter wishes to process.
     */
    public ArrayList<Actor> getActors()
    {
        ArrayList<Actor> actors = new ArrayList<>();
        ArrayList<Actor> res = new ArrayList<>();
        actors = getGrid().getNeighbors(getLocation());
        for (Actor a : actors)
        {
            if (!(a instanceof Rock) && !(a instanceof Critter))
            {
                if(this.getDirection() == 0 && 
                    a.getLocation().getRow() == this.getLocation().getRow()-1){
                    res.add(a);
                }
                else if(this.getDirection() == 180 && 
                    a.getLocation().getRow() == this.getLocation().getRow()+1){
                    res.add(a);
                }
                else if(this.getDirection() == 90 && 
                    a.getLocation().getCol() == this.getLocation().getCol()+1){
                    res.add(a);
                }
                else if(this.getDirection() == 270 && 
                    a.getLocation().getCol() == this.getLocation().getCol()-1){
                    res.add(a);
                }

            }
        }
        return res;
    }

    /**
     * Gets a list of possible locations for the next move. These locations must
     * be valid in the grid of this crabcritter.<br />
     * Postcondition: The state of all actors is unchanged.
     * @return a list of possible locations for the next move
     */
    public ArrayList<Location> getMoveLocations()
    {
        ArrayList<Location> locs = new ArrayList<>();
        ArrayList<Location> res = new ArrayList<>();
        locs = getGrid().getEmptyAdjacentLocations(getLocation());
        for(Location a : locs){
            if(this.getDirection() == 0 || this.getDirection() == 180){
                if(a.getLocation().getRow() == this.getLocation().getRow())
                    res.add(a);
            }
            else if(this.getDirection() == 90 || this.getDirection() == 270){
                if(a.getLocation().getCol() == this.getLocation().getCol())
                    res.add(a)
            }
        }
        return res;
    }

    /**
     * Moves this critter to the given location <code>loc</code>, or turn
     * this critter left or right if <code>loc</code> is <code>null</code>.
     * Postcondition: (1) <code>getLocation() == loc</code>. (2) The state of
     * all actors other than those at the old and new locations is unchanged.
     * @param loc the location to move to
     */
    public void makeMove(Location loc){
        if (loc == null)
        {
            int r = (int) (Math.random() * 2);
            if(r == 0)
                setDirection(getDirection() + Location.LEFT);
            else
                setDirection(getDirection() + Location.RIGHT);
        }
        else
            moveTo(loc);
    }
}